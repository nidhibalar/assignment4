<?php

 $hostname = "localhost";
 $username = "root";
 $password = "";
 $dbname = "nidhi";

$link = mysqli_connect($hostname, $username, $password, $dbname);

mysqli_set_charset($link,"utf8");
?>

