function onbodyload() {
	$name = localStorage.getItem("logo");
	$("#logo").html($name);
	
}

function getrecords() {
		$("#cars").html("");
        $.ajax({
            url: "api.php?method=getrecords",
            method: "POST",
            data: {
            },
            datatype: 'json',
            success: function (response) {
            	$("#cars").append("<h4 align='center'>Car List</h4><table id='rfeeds' class='table table-striped table-bordered' width='100%'><thead><tr><th>No</th><th>Seller Name</th><th>Phone Number</th><th>Email</th><th>Address</th><th>City</th><th>Vehicle Make</th><th>Vehicle Model</th><th>Vehicle Year</th><th>JD Link</th></tr></thead><tbody id='feeds'></tbody></table>");
                let data = JSON.parse(response);
                $.each(data,function(feed,feed){
                    $("#feeds").append("<tr><td>"+feed.id+"</td><td>"+feed.sname+"</td><td>"+feed.snum+"</td><td>"+feed.smail+"</td><td>"+feed.sadd+"</td><td>"+feed.scity+"</td><td>"+feed.vmk+"</td><td>"+feed.vmod+"</td><td>"+feed.vyear+"</td><td><a href='"+feed.jd+"' target='_blank'>J.D. Power</a></td></tr>");
            });
            	$('#rfeeds').DataTable();
            },
            error: function (response) {
                 console.log(response);
            }
        });   
}

function addcar() {
    sname = $("#sname").val();
    pnumber = $("#pnumber").val();
  	email = $("#email").val();
	add = $("#add").val();
	city = $("#city").val();
	vmk = $("#vmk").val();
    vmod = $("#vmod").val();
    yyear = $("#yyear").val();
    jd = "http://www.jdpower.com/cars/"+vmk+"/"+vmod+"/"+yyear+""
        $.ajax({
            url: "api.php?method=add",
            method: "POST",
            data: {
                sname: sname,
                pnumber: pnumber,
                email: email,
                add: add,
                city: city,
                vmk: vmk,
                vmod: vmod,
                yyear: yyear,
                jd: jd,
            },
            datatype: 'json',
            success: function (response) {
                console.log("response" + JSON.parse(response));
                if (response !== "true") {
                	$("#close_btn").trigger("click");
                	$("#alert").append("<div class='alert alert-success' role='alert'>Car Added successfully</div>");
                	setTimeout(function(){
			           $("#alert").html("");
			      }, 800);
                }
                setTimeout(function(){
			           location.reload(); 
			      }, 1000);
            },
            error: function (response) {
            }
        });
}

function velidateinputs(){
	val = "0";
	var name = $("#sname").val();
	if ( name == "") {
		alert("Please Enter Seller Full Name");
		val = "1";
	}

	var phone = $("#pnumber").val();
  var phoneno = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$/;
  var digits = phone.replace(/\D/g, "");
  var x = phoneno.test(phone);
  if (x == "0") {
  	alert ("Please Enter Velid Number in XXX-XXX-XXXX Format");
  	val = "1";
  }

  var email = $("#email").val();
  var atpos = email.indexOf("@");
  var dotpos = email.lastIndexOf(".");
  if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
    alert("Not a valid e-mail address");
    val = "1";
  }

	var add = $("#add").val();
	if ( add == "") {
		alert("Please Enter Seller address");
		val = "1";
	}

	var city = $("#city").val();
	if ( city == "") {
		alert("Please Enter Seller city");
		val = "1";
	}

		var vmk = $("#vmk").val();
	if ( vmk == "") {
		alert("Please Enter Make");
		val = "1";
	}
		var vmod = $("#vmod").val();
		if ( vmod == "") {
		alert("Please Enter Model Name");
		val = "1";
	}
  var yyear = $("#yyear").val();
  if ( yyear == "") {
		alert("Please Enter Year");
		val = "1";
	}

	if (val == "1") {

	}else{
		addcar();	
	}

}