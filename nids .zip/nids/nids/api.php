<?php

date_default_timezone_set("Asia/Bangkok");
include 'db_config.php';

header("Access-Control-Allow-Origin: *");

$method = $_GET['method'];

$obj = new cars();

if ($method == 'getrecords') {
    $obj->getrecords();
} 
else if ($method == 'add') {
    $obj->add();
}
    else {
    echo 'why are you here';
}
class cars
{
    public function __construct()
    {

    }

    public function getrecords()
    {
        include 'db_config.php';

        $sql = "SELECT * FROM `info`";
        $result = mysqli_query($link, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        echo json_encode($data);
    }

    public function add()
    {
        $sname = isset($_POST['sname']) ? $_POST['sname'] : "";
        $pnumber = isset($_POST['pnumber']) ? $_POST['pnumber'] : "";
        $email = isset($_POST['email']) ? $_POST['email'] : "";
        $add = isset($_POST['add']) ? $_POST['add'] : "";
        $city = isset($_POST['city']) ? $_POST['city'] : "";
        $vmk = isset($_POST['vmk']) ? $_POST['vmk'] : "";
        $vmod = isset($_POST['vmod']) ? $_POST['vmod'] : "";
        $yyear = isset($_POST['yyear']) ? $_POST['yyear'] : "";
        $jd = isset($_POST['jd']) ? $_POST['jd'] : "";
        include 'db_config.php';

        $sql = "INSERT INTO `info` (`sname`, `snum`, `smail`, `sadd`, `scity`, `vmk`, `vmod`, `vyear`, `jd`) VALUES ('$sname', '$pnumber', '$email', '$add', '$city', '$vmk', '$vmod', '$yyear', '$jd');";
        $result = mysqli_query($link, $sql);
        echo json_encode($result);
    }

}

